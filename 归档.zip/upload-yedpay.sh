scp -r -P 44232 dist/* root@61.144.84.19:/usr/local/openresty/nginx/web/yedpayadmin
