scp -r dist/* root@120.24.39.193:/usr/share/pf

