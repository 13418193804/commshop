import axios from 'axios';

import * as Config from './conf.js';


import * as Api from './api.js';

 let base =Config.g_base_url;


export const requestOrderList = (goodsId,orderStatus) => {

    let data={
        token:'1111',
        userId:'222',
        page:0,
        pageSize:20
    }

    return Api.requestForm('/order/manager/queryorder' ,data)
        .then(res => {
            if (res.status == 200 && res.data.status == 200) {

                return { retCode: true, message: '', data: res.data.data }
            } else {

                console.log(res.data)

                console.log(res.data.message)
                return {
                    retCode: false,
                    message: res.data.message,
                    data: res.data.data
                }
                    ;

            }

        })
        .catch(error => {

            console.error("requestOrderList")
            console.error(error)


        });




};

export const requestOrderDetail = (orderId) => {
    
        let data={
            token:'1111',
            userId:'222',
            orderId:orderId
        }
    
        return Api.requestForm('/order/manager/queryorderdetail' ,data)
            .then(res => {
                if (res.status == 200 && res.data.status == 200) {
    
                    return { retCode: true, message: '', data: res.data.data }
                } else {
    
                    console.log(res.data)
    
                    console.log(res.data.message)
                    return {
                        retCode: false,
                        message: res.data.message,
                        data: res.data.data
                    }
                        ;
    
                }
    
            })
            .catch(error => {
    
                console.error("requestOrderList")
                console.error(error)
    
    
            });
    
    
    
    
    };

    export const requestSendGoods = (orderId,transName,transNo) => {
        
            let data={
                token:'1111',
                userId:'222',
                orderId:orderId,
                transName:transName,
                transNo:transNo
            }
        
            return Api.requestForm('/order/manager/sendgoods' ,data)
                .then(res => {
                    if (res.status == 200 && res.data.status == 200) {
        
                        return { retCode: true, message: '', data: res.data.data }
                    } else {
                        return {
                            retCode: false,
                            message: "request code"+res.status,
                            data: {}
                        }
        
                    }
        
                })
                .catch(error => {
        
                    console.error("requestSendGoods")
                    console.error(error)

                    return {
                        retCode: false,
                        data: {}
                    }
    
        
        
                });
        
        
        
        
        };
        
        






