 
// export const g_base_url ='http://61.144.84.19:8032/api/'
// export const g_upload_url='http://61.144.84.19:8032/api//fileupload'



 export const g_base_url ='https://mapp.aisimob.com/tfj/'
 export const g_upload_url='https://mapp.aisimob.com/tfj/fileupload'

// export const g_base_url ='http://127.0.0.1:9090'
// export const g_upload_url='http://127.0.0.1:9090/fileupload'
