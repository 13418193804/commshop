import axios from 'axios';

import * as Config from './conf.js';


import * as Api from './api.js';

 let base =Config.g_base_url;



export const queryMainPortal = (appid) => {
    
        let data={
            appid:appid
        }
    
        return Api.requestForm2('/page/mainpage',data)
            .then(res=>res); 
           
    
    };

 
