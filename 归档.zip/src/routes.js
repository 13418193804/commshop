import Login from './views/Login.vue'
import NotFound from './views/404.vue'
import Home from './views/Home.vue'
import Main from './views/Main.vue'
import Table from './views/nav1/Table.vue'
import Form from './views/nav1/Form.vue'
import user from './views/nav1/user.vue'
import Page4 from './views/nav2/Page4.vue'
import Page5 from './views/nav2/Page5.vue'
import Page6 from './views/nav3/Page6.vue'
import echarts from './views/charts/echarts.vue'

import AddGoods from './views/goods/AddGoods.vue'

import GoodsList from './views/goods/GoodsList.vue'
import Category from './views/goods/Category.vue'

import OrderList from './views/order/OrderList.vue'


import MemberList from './views/member/MemberList.vue'


import OrderDetail from './views/order/OrderDetail.vue'


import MainPage from './views/custompage/MainPage.vue'

let routes = [
    {
        path: '/login',
        component: Login,
        name: 'login',
        hidden: true
    },
    {
        path: '/404',
        component: NotFound,
        name: 'notfound',
        hidden: true
    },
    //{ path: '/main', component: Main },

     {
        path: '/',
        component: Home,
        name: '消息',
        iconCls: 'el-icon-message',//图标样式class
        children: [
            { path: '/main', component: Main, name: '商品详情列表', hidden: true },
            { path: '/table', component: Table, name: '任务通知' },
            { path: '/form', component: Form, name: '页面变化' },
        ]
    },

       {
        path: '/',
        component: Home,
        name: '页面',
        iconCls: 'el-icon-message',//图标样式class
        children: [
            { path: '/mainpage', component: MainPage, name: '首页' },
            { path: '/table', component: Table, name: '栏目' },
            { path: '/table', component: Table, name: '分类' },
        ]
    },
  
   
    {
        path: '/',
        component: Home,
        name: '商品',
        iconCls: 'el-icon-message',//图标样式class
        children: [
            { path: '/goodslist', component: GoodsList, name: '商品列表' },
            { path: '/addgoods', component: AddGoods, name: '添加商品' },
            { path: '/category', component: Category, name: '商品分类' },
            { path: '/form', component: Form, name: '商品标签' },
        ]
    },
    {
        path: '/',
        component: Home,
        name: '订单',
        iconCls: 'fa fa-id-card-o',
        children: [
            { path: '/orderlist', component: OrderList, name: '订单列表' },
            { path: '/orderdetail', component: OrderDetail, name: '订单详情',hidden: true },
            { path: '/table5', component: Page5, name: '订单状态' },
            { path: '/table6', component: Page5, name: '订单分类' },

        ]
    },
    {
        path: '/',
        component: Home,
        name: '会员',
        iconCls: 'fa fa-address-card',
        children: [
            { path: '/memberlist', component: MemberList, name: '会员列表' },
            { path: '/table2', component: Page6, name: '会员状态22' },
            { path: '/table3', component: Page6, name: '会员分类' },
 
        ]
    },
    {
        path: '/',
        component: Home,
        name: '报表',
        iconCls: 'fa fa-bar-chart',
        children: [
            { path: '/echarts7', component: echarts, name: '销售报表' },
           { path: '/echarts8', component: echarts, name: '资金报表' },
             { path: '/echarts9', component: echarts, name: '商户报表' }
   
   
        ]
    },

    {
        path: '/',
        component: Home,
        name: '用户',
        iconCls: 'fa fa-address-card',
        children: [
            { path: '/table11', component: Page6, name: '权限分配' },
            { path: '/table12', component: Page6, name: '用户查询' }
   
        ]
    },
       {
        path: '/',
        component: Home,
        name: '系统',
        iconCls: 'fa fa-bar-chart',
        children: [
         { path: '/table13', component: Page6, name: '会员状态' },
         { path: '/table14', component: Page6, name: '会员状态2' },
         
         ]
    },

  
   
    {
        path: '*',
        hidden: true,
        redirect: { path: '/404' }
    }
];

export default routes;