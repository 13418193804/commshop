<template>
	<section>
		<!--工具条-->
		<el-col :span="24" class="toolbar" style="padding-bottom: 0px;">
			<el-form :inline="true" :model="searchForm">
				<el-row>
					<el-form-item>
						<el-input v-model="searchForm.name" placeholder="商品名称"></el-input>
					</el-form-item>

					<el-form-item>
						<el-input v-model="searchForm.code" placeholder="商家编码"></el-input>
					</el-form-item>

					<el-form-item>

						<el-cascader style="width:200px;" placeholder="分类" v-model="searchForm.catIdList" :options="options"
						 filterable  @change="doQueryByCat"></el-cascader>

					</el-form-item>

					<el-form-item>

						<el-date-picker v-model="searchForm.beginDate" type="date" placeholder="开始日期">
						</el-date-picker>
					</el-form-item>
					<el-form-item>
						<el-date-picker v-model="searchForm.endDate" type="date" placeholder="结束日期">
						</el-date-picker>

					</el-form-item>
				</el-row>
				<el-row>
					<el-form-item>
						<el-button type="primary" size="small" plain @click="doQuery">查询</el-button>
					</el-form-item>

					<el-form-item>
						<el-button type="reset" size="small" plain @click="doResetQuery">重置</el-button>
					</el-form-item>

					<el-form-item>
						<el-button  type="success" size="small" @click="handleAdd">新增商品</el-button>
					</el-form-item>
				</el-row>
			</el-form>
		</el-col>

		<!--列表-->
		<el-table :data="goodsData" highlight-current-row v-loading="listLoading" style="width: 120%;">
			<el-table-column type="selection" width="55">
			</el-table-column>
			<el-table-column prop="id" label="商品ID" width="120" sortable>
			</el-table-column>

			<el-table-column prop="logo_url" label="商品图片" width="160">

				<template scope="scope">
					<img :src="scope.row.logoUrl" style="width:80px;height:80px;">
				</template>

			</el-table-column>

			<el-table-column prop="name" label="商品名" width="160" sortable>
			</el-table-column>
			<el-table-column prop="code" label="商家编码" width="110" sortable>
			</el-table-column>
			<el-table-column prop="storageNum" label="库存" width="100" sortable>
			</el-table-column>
			<el-table-column prop="labelPrice" label="标签价" width="100" sortable>
			</el-table-column>
			<el-table-column prop="marketPrice" label="市场价" min-width="100" sortable>
			</el-table-column>
			<el-table-column label="操作" width="350">
				<template scope="scope">
					<el-button v-if="scope.row.onlineStatus==true" size="mini" plain  @click="handleOffline(scope.$index, scope.row)">下架</el-button>
				
					<el-button v-if="scope.row.onlineStatus==false" size="mini" type="primary" plain @click="handleOnline(scope.$index, scope.row)">上架</el-button>
				
					<el-button size="mini" @click="handleEdit(scope.$index, scope.row)">库存</el-button>
					<el-button size="mini" @click="handleEdit(scope.$index, scope.row)" type="info" plain>编辑</el-button>
					<el-button size="mini" type="danger" @click="handleDelete(scope.$index, scope.row)" plain>删除</el-button>

				</template>
			</el-table-column>
		</el-table>

		<!--工具条-->
		<el-col :span="24" class="toolbar">

			<el-pagination layout="prev, pager, next" 
			:page-size="pageSize" :total="total"
			@current-change="onPageChange">
			</el-pagination>
		</el-col>

		<!--编辑界面-->

		<!--新增界面-->

	</section>
</template>

<script>
import util from '../../common/js/util'
//import NProgress from 'nprogress'
import * as Api from '../../api/api.js'


export default {
	data() {
		return {
			pageSize: 20,
			total: 100,
			currentPage:0,

			options: [],
			searchForm: {
				name: '',
				code: '',
				catId: '',
				beginDate: '',
				endDate: '',
				catIdList: [],

			},

		

			goodsData: [],
			total: 0,
			page: 1,
			listLoading: false,
			sels: [],//列表选中列

			editFormVisible: false,//编辑界面是否显示
			editLoading: false,
			editFormRules: {
				name: [
					{ required: true, message: '请输入姓名', trigger: 'blur' }
				]
			},
		
		}
	},
	methods: {
		//性别显示转换


		doQueryByCat(){


			let pos = this.searchForm.catIdList.length;

			if(pos>0){

				let catId = this.searchForm.catIdList[pos-1];

				Api.requestQueryGoodsByCat(catId).then(res => {

					this.total = 100

					this.goodsData = res.data;

				})

			}
			

			
		
	


		},

		onChangeCatId(){

			this.doQueryByCat()

	
		},


		onPageChange(page){

			console.log(page);

			this.currentPage = page-1;

			this.doQuery()
		},


		//获取用户列表

		doQueryTree() {
			Api.requestQueryTree().then(res => {
				this.options = res.data.children

			})

		},


		doResetQuery() {
			this.searchForm.name = ""
			this.searchForm.code = ""
			this.searchForm.beginDate = ""
			this.searchForm.endDate = ""
			this.searchForm.catIdList=["",""]

			this.doQuery()


		},
		doQuery() {
			let params = {

			}
			if ((this.searchForm.name || '') != '') {

				params.name = this.searchForm.name


			}

			if ((this.searchForm.code || '') != '') {

				params.code = this.searchForm.code


			}

			if ((this.searchForm.beginDate || '') != '') {

				params.beginDate = this.moment(this.searchForm.beginDate).format("YYYY-MM-DD") + " 00:00:00"



			}



			console.log(this.searchForm.endDate)

			if ((this.searchForm.endDate || '') != '') {


				params.endDate = this.moment(this.searchForm.endDate).format("YYYY-MM-DD") + " 23:59:59"


			}




			params.page=this.currentPage



			Api.requestQueryGoods(params).then(res => {

				this.total = res.page.total

				this.goodsData = res.data;

			})





		},

		handleOffline(index,row){

			Api.doConfirm(this,"是否要将该商品下架！").then(res=>{

				Api.requestOnlineGoods(row.id,false).then(ret=>{

					this.doQuery();

					this.$message("商品下架成功")


				})

			})
	



		},

				//修改
		handleOnline(index, row) {
			console.log(row.id)
		Api.doConfirm(this,"是否要将该商品上架！").then(res=>{

				Api.requestOnlineGoods(row.id,true).then(ret=>{

					this.doQuery();
					this.$message("商品上架成功")

				})

			})
	
		},


		//修改
		handleEdit(index, row) {
			console.log(row.id)
			this.$router.push({ name: "添加商品", params: { goodsId: row.id } })

		},

		handleDelete(index, row) {
			console.log(row.id)

			Api.doConfirm(this,"是否需要删除该信息!").then(res=>{
				if(res){

					Api.requestDeleteGoods(row.id).then(res=>{
							this.doQuery();

					})
				}


			});


	
		},
	
		//显示新增界面
		handleAdd() {
			this.$router.push("/addgoods")
		},

		//批量删除
	},
	mounted() {
		this.doQuery();
		this.doQueryTree();
	}
}

</script>

<style scoped>

</style>